package org;

public class VehicleModel {
	public int id; public String vehicleNumber;
	public String vehicleType; 
	public int slotId; 
	public String entryTime;
	public String exitTime; 
	public double bill; 
	}
